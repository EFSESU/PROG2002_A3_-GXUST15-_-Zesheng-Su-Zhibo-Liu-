import { Component } from '@angular/core';

@Component({
  selector: 'app-my-new-page',
  standalone: true,
  imports: [],
  templateUrl: './my-new-page.component.html',
  styleUrl: './my-new-page.component.css'
})
export class MyNewPageComponent {

}
