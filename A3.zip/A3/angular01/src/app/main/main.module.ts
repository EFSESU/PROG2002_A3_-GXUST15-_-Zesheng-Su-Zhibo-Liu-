import { NgModule } from '@angular/core';
import { CommonModule } from '@angular/common';  // 导入 CommonModule
import { MainComponent } from './main.component';

@NgModule({
  declarations: [
    MainComponent
  ],
  imports: [
    CommonModule  // 导入 CommonModule
  ],
  exports: [
    MainComponent
  ]
})
export class MainModule { }